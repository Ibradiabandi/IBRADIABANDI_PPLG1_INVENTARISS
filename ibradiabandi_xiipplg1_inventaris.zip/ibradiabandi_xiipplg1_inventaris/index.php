<?php
include 'koneksi.php';

$kategori_result = $conn->query("SELECT * FROM kategori");

$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM barang WHERE 1";

if ($filter_kategori != '') {
  $query .= " AND kategori_barang = '$filter_kategori'";
}
if ($search != '') {
  $query .= " AND nama_barang LIKE '%$search%'";
}

$result = $conn->query($query);

$total_barang = $conn->query("SELECT COUNT(*) AS total FROM barang")->fetch_assoc()['total'];
$total_kategori = $conn->query("SELECT COUNT(DISTINCT kategori_barang) AS total FROM barang")->fetch_assoc()['total'];
$stok_menipis = $conn->query("SELECT COUNT(*) AS total FROM barang WHERE jumlah_stok < 10")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Inventaris Gudang</title>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.min.js"></script>


<style>
body {
    background: #f1f1f1;
    font-family: "Poppins", sans-serif;
}

.sidebar {
    width: 230px;
    background: #333;
    color: #fff;
    min-height: 100vh;
    padding: 20px;
    position: fixed;
    left: 0;
    top: 0;
    transition: .3s;
    z-index: 1000;
}
.sidebar h3 {
    text-align: center;
    font-size: 20px;
    margin-bottom: 25px;
}
.sidebar a {
    display: block;
    padding: 12px;
    color: #ddd;
    text-decoration: none;
    font-size: 15px;
    border-radius: 6px;
    margin-bottom: 10px;
}
.sidebar a:hover,
.sidebar a.active {
    background: #555;
    color: #fff;
}

.content {
    margin-left: 260px;
    padding: 25px;
}

.summary-card {
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    background: white;
    color: #333;
    border: 1px solid #d1d1d1;
    box-shadow: 0 2px 5px rgba(0,0,0,.05);
}
.summary-card h2 {
    font-size: 32px;
    margin: 0;
    font-weight: bold;
}
.summary-card h6 {
    color: #666;
    margin-bottom: 8px;
}
.c1 { border-left: 6px solid #7a7a7a; }
.c2 { border-left: 6px solid #999; }
.c3 { border-left: 6px solid #c2c2c2; }

.filter-box {
    background: white;
    padding: 18px;
    border-radius: 12px;
    border-left: 5px solid #bfbfbf;
    border: 1px solid #d1d1d1;
}
.filter-box .form-control,
.filter-box .form-select {
    height: 45px;
}
.filter-box button,
.filter-box a.btn {
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 500;
}

.table thead th {
    background: #bfbfbf;
    color: #222;
    border-bottom: 2px solid #a4a4a4;
}
.table-warning {
    background-color: #fff2d0 !important;
}

.card-header {
    background: #bfbfbf !important;
    color: #222 !important;
    font-weight: 600;
}

@media(max-width: 768px) {
    .sidebar {
        left: -260px;
    }
    .sidebar.active {
        left: 0;
    }
    .content {
        margin-left: 0;
        padding-top: 80px;
    }
    .toggle-btn {
        position: fixed;
        top: 15px;
        left: 15px;
        background: #333;
        color: #fff;
        border: none;
        padding: 10px 14px;
        border-radius: 6px;
        z-index: 1100;
    }
}
</style>
</head>

<body>

<button class="toggle-btn d-md-none" onclick="toggleSidebar()">☰</button>

<div class="sidebar" id="sidebar">
    <h3>📦 Inventaris</h3>
    <a href="home.php" class="active">🏠 Dashboard</a>
    <a href="barang.php">📋 Data Barang</a>
    <a href="kategori.php">📁 Kategori</a>
    <a href="tambah_barang.php">➕ Tambah Barang</a>
</div>

<div class="content">
    <h2 class="mb-4">Dashboard Inventaris Gudang</h2>

    <div class="row g-3 mb-4">
        <div class="col-lg-4 col-md-6">
            <div class="summary-card c1">
                <h6>Total Barang</h6>
                <h2><?= $total_barang ?></h2>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="summary-card c2">
                <h6>Total Kategori</h6>
                <h2><?= $total_kategori ?></h2>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="summary-card c3">
                <h6>Stok Menipis (&lt;10)</h6>
                <h2><?= $stok_menipis ?></h2>
            </div>
        </div>
    </div>

    <div class="filter-box mb-4">
        <form method="GET" class="row g-3">
            <div class="col-lg-4 col-md-6">
                <input type="text" name="search" class="form-control"
                    placeholder="Cari nama barang..." value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="col-lg-3 col-md-6">
                <select name="kategori" class="form-select">
                    <option value="">-- Semua Kategori --</option>
                    <?php while ($kat = $kategori_result->fetch_assoc()): ?>
                    <option value="<?= $kat['nama_kategori'] ?>" 
                        <?= ($filter_kategori == $kat['nama_kategori']) ? 'selected' : '' ?>>
                        <?= $kat['nama_kategori'] ?>
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-6">
                <button type="submit" class="btn btn-primary w-100">🔍 Cari</button>
            </div>

            <div class="col-lg-2 col-md-6">
                <a href="home.php" class="btn btn-secondary w-100">Reset</a>
            </div>
        </form>
    </div>

    <div class="card shadow-sm">
        <div class="card-header text-white" style="background:#ffb3d6; border-radius:10px 10px 0 0;">
            Daftar Barang
        </div>
        <div class="card-body p-0">
            <table class="table table-striped mb-0 text-center align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th>Tanggal Masuk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr class="<?= ($row['jumlah_stok'] < 10) ? 'table-warning' : '' ?>">
                        <td><?= $row['id_barang'] ?></td>
                        <td><?= $row['nama_barang'] ?></td>
                        <td><?= $row['kategori_barang'] ?></td>
                        <td><?= $row['jumlah_stok'] ?></td>
                        <td>Rp <?= number_format($row['harga_barang'], 0, ',', '.') ?></td>
                        <td><?= date('d-m-Y', strtotime($row['tanggal_masuk'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php else: ?>
                    <tr><td colspan="6" class="text-muted">Tidak ada data barang ditemukan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("active");
}
</script>

</body>
</html>
