<?php
include 'koneksi.php';

$limit = 5;
$page  = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$start = ($page - 1) * $limit;

$total = $conn->query("SELECT COUNT(*) as total FROM kategori")->fetch_assoc()['total'];
$pages = ceil($total / $limit);

$result = $conn->query("SELECT * FROM kategori ORDER BY id_kategori DESC LIMIT $start, $limit");

if (isset($_POST['tambah'])) {
  $nama = trim($_POST['nama_kategori']);
  if ($nama == '') {
    $error = "Nama kategori tidak boleh kosong!";
  } else {
    $cek = $conn->query("SELECT * FROM kategori WHERE nama_kategori='$nama'");
    if ($cek->num_rows > 0) {
      $error = "Kategori sudah ada!";
    } else {
      $conn->query("INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
      $success = "Kategori berhasil ditambahkan!";
    }
  }
}

if (isset($_GET['hapus'])) {
  $id = intval($_GET['hapus']);
  $conn->query("DELETE FROM kategori WHERE id_kategori=$id");
  $success = "Kategori berhasil dihapus!";
}

if (isset($_POST['update'])) {
  $id   = intval($_POST['id_kategori']);
  $nama = trim($_POST['nama_kategori']);
  if ($nama == '') {
    $error = "Nama kategori tidak boleh kosong!";
  } else {
    $conn->query("UPDATE kategori SET nama_kategori='$nama' WHERE id_kategori=$id");
    $success = "Kategori berhasil diperbarui!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Kategori</title>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.min.js"></script>

<style>
.sidebar {
    width: 240px;
    height: 100vh;
    background: #141414;
    position: fixed;
    left: 0;
    top: 0;
    padding: 25px 18px;
    border-right: 1px solid #2a2a2a;
    transition: 0.3s;
    z-index: 999;
}
.sidebar h3 {
    font-size: 22px;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 25px;
}
.sidebar a {
    display: block;
    padding: 12px;
    margin-bottom: 8px;
    text-decoration: none;
    font-weight: 500;
    color: #d3d3d3;
    border-radius: 8px;
    background: #1e1e1e;
    transition: 0.2s;
}
.sidebar a:hover,
.sidebar .active {
    background: #333333;
    color: #ffffff;
}

.content {
    margin-left: 260px;
    padding: 25px;
    transition: 0.3s;
}

.menu-toggle {
    display: none;
    position: fixed;
    top: 15px;
    left: 15px;
    z-index: 1001;
    background: #1f1f1f;
    color: #fff;
    border: none;
    padding: 10px 12px;
    font-size: 20px;
    border-radius: 8px;
}

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

@media(max-width: 768px) {
    .sidebar {
        left: -260px;
    }
    .sidebar.show {
        left: 0;
    }
    .menu-toggle {
        display: block;
    }
    .content {
        margin-left: 0;
        padding-top: 70px;
    }
    table td, table th {
        font-size: 13px;
        white-space: nowrap;
    }
    .col-md-8,
    .col-md-4 {
        width: 100%;
    }
}
</style>
</head>
<body>

<button class="menu-toggle" onclick="toggleMenu()">☰</button>

<div class="sidebar">
    <h3>📦 Inventaris</h3>
    <a href="index.php">🏠 Dashboard</a>
    <a href="barang.php">📋 Data Barang</a>
    <a href="kategori.php" class="active">📁 Kategori</a>
    <a href="tambah_barang.php">➕ Tambah Barang</a>
</div>

<div class="content">

<h2 class="mb-4">🏷️ Kelola Kategori Barang</h2>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= $error ?></div>
<?php elseif (isset($success)): ?>
  <div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<div class="card mb-4 shadow-sm">
    <div class="card-header">➕ Tambah Kategori</div>
    <div class="card-body">
        <form method="POST" class="row g-3">
            <div class="col-md-8">
                <input type="text" name="nama_kategori" class="form-control" placeholder="Masukkan nama kategori...">
            </div>
            <div class="col-md-4 d-grid">
                <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">📋 Daftar Kategori</div>
    <div class="card-body p-0 table-responsive">
        <table class="table table-striped text-center mb-0 align-middle">
            <thead>
                <tr>
                    <th width="10%">#</th>
                    <th>Nama Kategori</th>
                    <th width="25%">Aksi</th>
                </tr>
            </thead>
            <tbody>

            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_kategori'] ?></td>
                    <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id_kategori'] ?>">✏️ Edit</button>
                        <a href="?hapus=<?= $row['id_kategori'] ?>" onclick="return confirm('Hapus kategori ini?')" class="btn btn-danger btn-sm">🗑️ Hapus</a>
                    </td>
                </tr>

                <div class="modal fade" id="editModal<?= $row['id_kategori'] ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST">
                            <div class="modal-header bg-warning text-white">
                                <h5 class="modal-title">Edit Kategori</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>

                            <div class="modal-body">
                                <input type="hidden" name="id_kategori" value="<?= $row['id_kategori'] ?>">
                                <label>Nama Kategori</label>
                                <input type="text" name="nama_kategori" class="form-control" value="<?= htmlspecialchars($row['nama_kategori']) ?>">
                            </div>

                            <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-success">💾 Simpan</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            </div>
                        </form>
                    </div>
                  </div>
                </div>

                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="3" class="text-muted">Belum ada kategori.</td></tr>
            <?php endif; ?>

            </tbody>
        </table>

    </div>
</div>

<nav class="mt-3">
    <ul class="pagination justify-content-center">
        <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
            <a class="page-link" href="?page=1">First</a>
        </li>

        <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
            <a class="page-link" href="?page=<?= $page - 1 ?>">Prev</a>
        </li>

        <?php for ($i = 1; $i <= $pages; $i++): ?>
        <li class="page-item <?= ($i == $page ? 'active' : '') ?>">
            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
        </li>
        <?php endfor; ?>

        <li class="page-item <?= ($page >= $pages ? 'disabled' : '') ?>">
            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
        </li>

        <li class="page-item <?= ($page >= $pages ? 'disabled' : '') ?>">
            <a class="page-link" href="?page=<?= $pages ?>">Last</a>
        </li>
    </ul>
</nav>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
function toggleMenu() {
    document.querySelector('.sidebar').classList.toggle('show');
}
</script>

</body>
</html>
