<?php
include 'koneksi.php';

$limit = 5; 
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$start = ($page - 1) * $limit;

$countResult = $conn->query("SELECT COUNT(*) AS total FROM barang");
$totalData = $countResult->fetch_assoc()['total'];

$totalPages = ceil($totalData / $limit);

$result = $conn->query("SELECT * FROM barang ORDER BY id_barang DESC LIMIT $start, $limit");
?>
<!DOCTYPE html>
<html lang="id">
<head> 
  <meta charset="UTF-8">
  <title>Data Barang - Inventaris Gudang</title>
  <link rel="stylesheet" href="css/bootstrap.min.css"/>
  <script src="js/bootstrap.min.js"></script>

<style>
body { 
    background-color: #efefef; 
    font-family: "Poppins", sans-serif; 
    margin: 0;
    padding: 0;
}
.sidebar {
    width: 240px;
    height: 100vh;
    background: #1f1f1f;
    position: fixed;
    top: 0;
    left: 0;
    padding: 25px 18px;
    border-right: 2px solid #3a3a3a;
    transition: 0.3s ease;
    z-index: 998;
}
.sidebar h3 { 
    color: #fff;
    font-size: 22px; 
    font-weight: 700; 
    margin-bottom: 25px;
}
.sidebar a {
    display: block;
    padding: 12px;
    margin-bottom: 8px;
    text-decoration: none;
    font-weight: 500;
    color: #ddd;
    background: #2b2b2b;
    border-radius: 8px;
    transition: 0.2s;
}
.sidebar a:hover,
.sidebar .active {
    background: #3f3f3f;
    color: #fff;
}
.menu-toggle {
    display: none;
    position: fixed;
    top: 18px;
    left: 18px;
    background: #1f1f1f;
    color: #fff;
    border: none;
    padding: 10px 14px;
    font-size: 22px;
    border-radius: 6px;
    z-index: 999;
    cursor: pointer;
}
.content {
    margin-left: 260px;
    padding: 25px;
}
@media (max-width: 768px) {
    .menu-toggle {
        display: block;
    }
    .sidebar {
        left: -260px;
        height: 100vh;
    }
    .sidebar.show {
        left: 0;
    }
    .content {
        margin-left: 0;
        padding: 20px;
    }
}
h2 {
    font-size: 30px;
    font-weight: 600;
    color: #333;
}
.card { 
    border-radius: 12px; 
    border: 1px solid #d0d0d0;
}
.card-header { 
    background-color: #bfbfbf !important; 
    color: #222 !important; 
    font-size: 18px;
    font-weight: 600;
}
.table thead th { 
    background-color: #bfbfbf; 
    color: #222; 
    border-bottom: 2px solid #a8a8a8;
}
.table-striped tbody tr:nth-child(odd) {
    background-color: #f6f6f6;
}
.table-warning {
    background-color: #fff2d3 !important;
}
.btn {
    border-radius: 10px;
    font-size: 14px;
    padding: 6px 12px;
}
.btn-primary {
    background: #6c757d;
    border: none;
}
.btn-primary:hover {
    background: #5c636a;
}
.btn-secondary {
    background: #b3b3b3;
    border: none;
}
.btn-secondary:hover {
    background: #9d9d9d;
}
.btn-warning {
    background: #b5b5b5;
    border: none;
    color: #000;
}
.btn-warning:hover {
    background: #8c8c8c;
}
.btn-danger {
    background: #d66c6c;
    border: none;
}
.btn-danger:hover {
    background: #bb5858;
}
.pagination .page-link {
    border-radius: 8px !important;
    font-size: 14px;
}
.pagination .active .page-link {
    background: #6c757d !important;
}
</style>
</head>

<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <h3>📦 Inventaris</h3>
    <a href="index.php">🏠 Dashboard</a>
    <a href="barang.php" class="active">📋 Data Barang</a>
    <a href="kategori.php">📁 Kategori</a>
    <a href="tambah_barang.php">➕ Tambah Barang</a>
</div>

<div class="content">

  <h2 class="text-center mb-4">Data Barang Gudang</h2>

  <div class="d-flex justify-content-between mb-3">
    <a href="tambah_barang.php" class="btn btn-primary">Tambah Barang</a>
    <a href="index.php" class="btn btn-secondary">Kembali ke Dashboard</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-header">Daftar Barang</div>

    <div class="card-body p-0">
      <table class="table table-striped text-center align-middle mb-0">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
            <th>Aksi</th>
          </tr>
        </thead>

        <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
              <tr class="<?= ($row['jumlah_stok'] < 10) ? 'table-warning' : '' ?>">
                <td><?= $row['id_barang'] ?></td>
                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                <td><?= htmlspecialchars($row['kategori_barang']) ?></td>
                <td><?= $row['jumlah_stok'] ?></td>
                <td>Rp <?= number_format($row['harga_barang'], 0, ',', '.') ?></td>
                <td><?= date('d-m-Y', strtotime($row['tanggal_masuk'])) ?></td>
                <td>
                  <a href="edit_barang.php?id=<?= $row['id_barang'] ?>" class="btn btn-warning btn-sm">✏️ Edit</a>
                  <a href="hapus_barang.php?id=<?= $row['id_barang'] ?>" onclick="return confirm('Yakin ingin menghapus barang ini?')" class="btn btn-danger btn-sm">🗑️ Hapus</a>
                </td>
              </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7" class="text-muted py-3">Belum ada data barang.</td></tr>
        <?php endif; ?>
        </tbody>

      </table>
    </div>
  </div>

  <nav class="mt-3">
    <ul class="pagination justify-content-center">

      <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
        <a class="page-link" href="?page=<?= $page - 1 ?>">Prev</a>
      </li>

      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <li class="page-item <?= ($i == $page ? 'active' : '') ?>">
          <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
        </li>
      <?php endfor; ?>

      <li class="page-item <?= ($page >= $totalPages ? 'disabled' : '') ?>">
        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
      </li>

    </ul>
  </nav>

</div>

<script>
function toggleSidebar() {
    document.querySelector(".sidebar").classList.toggle("show");
}
</script>

</body>
</html>
