<?php
include 'koneksi.php';

if (!isset($_GET['id'])) {
    header("Location: barang.php");
    exit;
}

$id = intval($_GET['id']);
$result = $conn->query("SELECT * FROM barang WHERE id_barang = $id");

if ($result->num_rows === 0) {
    echo "<script>alert('Barang tidak ditemukan!'); window.location='barang.php';</script>";
    exit;
}

$data = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $nama     = mysqli_real_escape_string($conn, $_POST['nama_barang']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori_barang']);
    $stok     = intval($_POST['jumlah_stok']);
    $harga    = intval($_POST['harga_barang']);
    $tanggal  = $_POST['tanggal_masuk'];

    if ($nama == "" || $kategori == "" || $stok == "" || $harga == "") {
        $error = "Semua field harus diisi!";
    } else {
        $update = $conn->query("
            UPDATE barang SET 
                nama_barang = '$nama',
                kategori_barang = '$kategori',
                jumlah_stok = $stok,
                harga_barang = $harga,
                tanggal_masuk = '$tanggal'
            WHERE id_barang = $id
        ");

        if ($update) {
            echo "<script>alert('Data berhasil diperbarui!'); window.location='barang.php';</script>";
            exit;
        } else {
            $error = "Gagal memperbarui data: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Barang</title>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.min.js"></script>

<style>
body {
    font-family: Poppins, sans-serif;
    background: #f2f2f2;
}
.card {
    border-radius: 15px;
    border: 1px solid #d9d9d9;
    background: #ffffff;
    box-shadow: 0 4px 10px rgba(0,0,0,0.07);
}
.card-header {
    background: #b5b5b5 !important;
    color: white;
    font-weight: bold;
    border-radius: 15px 15px 0 0;
}
.form-control, 
.form-select {
    border: 2px solid #d4d4d4;
    background: #fafafa;
    padding: 10px;
    border-radius: 10px;
}
.form-control:focus,
.form-select:focus {
    border-color: #9e9e9e;
    background: #fff;
    box-shadow: 0 0 6px rgba(158,158,158,0.5);
}
.btn {
    border-radius: 10px;
    font-weight: 600;
}
.btn-success {
    background: #8e8e8e;
    border: none;
}
.btn-success:hover {
    background: #7c7c7c;
}
.btn-secondary {
    background: #cfcfcf;
    border: none;
}
.btn-secondary:hover {
    background: #bcbcbc;
}
</style>
</head>
<body>

<div class="container py-4">
    <h2 class="text-center mb-4 text-primary">Edit Data Barang</h2>

    <div class="card">
        <div class="card-header">Form Edit Barang</div>
        <div class="card-body">

            <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">

                <div class="mb-3">
                    <label>Nama Barang</label>
                    <input type="text" name="nama_barang" class="form-control"
                           value="<?= htmlspecialchars($data['nama_barang']) ?>">
                </div>

                <div class="mb-3">
                    <label>Kategori</label>
                    <input type="text" name="kategori_barang" class="form-control"
                           value="<?= htmlspecialchars($data['kategori_barang']) ?>">
                </div>

                <div class="mb-3">
                    <label>Jumlah Stok</label>
                    <input type="number" name="jumlah_stok" class="form-control"
                           value="<?= $data['jumlah_stok'] ?>">
                </div>

                <div class="mb-3">
                    <label>Harga Barang</label>
                    <input type="number" name="harga_barang" class="form-control"
                           value="<?= $data['harga_barang'] ?>">
                </div>

                <div class="mb-3">
                    <label>Tanggal Masuk</label>
                    <input type="date" name="tanggal_masuk" class="form-control"
                           value="<?= $data['tanggal_masuk'] ?>">
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" name="update" class="btn btn-success px-4">Simpan</button>
                    <a href="barang.php" class="btn btn-secondary px-4">Kembali</a>
                </div>

            </form>

        </div>
    </div>
</div>

</body>
</html>
 