<?php
$host = "localhost";
$user = "root";
$pass= "";
$db="ibradiabandi_xiirpl_inventaris";


$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi jelek: " . $conn -> connect_error);
}
?>