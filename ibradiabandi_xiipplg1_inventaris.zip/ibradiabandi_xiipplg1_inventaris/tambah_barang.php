<?php
include "koneksi.php";

$kategori_result = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_barang'];
    $kategori = $_POST['kategori_barang'];
    $stok = $_POST['jumlah_stok'];
    $harga = $_POST['harga_barang'];
    $tanggal_masuk = $_POST['tanggal_masuk'];

    $query = "INSERT INTO barang (nama_barang, kategori_barang, jumlah_stok, harga_barang, tanggal_masuk)
              VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal_masuk')";
    mysqli_query($conn, $query);

    header("Location: barang.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Barang</title>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.min.js"></script>
<style>
body { 
    background-color: #efefef; 
    font-family: "Poppins", sans-serif; 
}
.container-box {
    width: 70%;
    margin: 40px auto;
    background: #ffffff;
    padding: 30px 35px;
    border-radius: 14px;
    border: 1px solid #d0d0d0;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
h2 {
    text-align: center;
    font-size: 28px;
    font-weight: 700;
    color: #4a4a4a;
    margin-bottom: 25px;
}
label {
    font-weight: 600;
    color: #4a4a4a;
}
.input-grey {
    border: 2px solid #dcdcdc;
    background: #f7f7f7;
    padding: 10px;
    border-radius: 10px;
    width: 100%;
    transition: .2s;
    color: #333;
    font-size: 14px;
}
.input-grey:focus {
    background: #fff;
    border-color: #bfbfbf;
    outline: none;
    box-shadow: 0 0 6px rgba(180,180,180,0.5);
}
.row {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
}
.col-md-6 {
    width: 48%;
}
.col-center {
    width: 48%;
    margin: 0 auto;
}
.btn {
    padding: 10px 25px;
    border-radius: 10px;
    font-size: 14px;
    cursor: pointer;
    font-weight: 600;
    border: none;
    text-decoration: none;
}
.btn-primary-grey {
    background: #6c757d;
    color: #fff;
}
.btn-primary-grey:hover {
    background: #5c636a;
}
.btn-secondary-grey {
    background: #b3b3b3;
    color: #222;
}
.btn-secondary-grey:hover {
    background: #9d9d9d;
}
.text-end {
    text-align: right;
    margin-top: 20px;
}
@media (max-width: 768px) {
    .container-box { width: 90%; }
    .col-md-6, .col-center { width: 100%; }
}
</style>
</head>
<body>

<div class="container-box">
    <h2>Tambah Data Barang</h2>

    <form method="POST" class="row">

        <div class="col-md-6">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="input-grey" placeholder="Masukkan nama barang..." required>
        </div>

        <div class="col-md-6">
            <label>Kategori Barang</label>
            <select name="kategori_barang" class="input-grey" required>
                <option value="">-- Pilih Kategori --</option>
                <?php while ($row = $kategori_result->fetch_assoc()): ?>
                    <option value="<?= $row['nama_kategori'] ?>"><?= $row['nama_kategori'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="col-md-6">
            <label>Jumlah Stok</label>
            <input type="number" name="jumlah_stok" class="input-grey" placeholder="Masukkan stok barang..." required>
        </div>

        <div class="col-md-6">
            <label>Harga Barang</label>
            <input type="number" name="harga_barang" class="input-grey" placeholder="Masukkan harga barang..." required>
        </div>

        <div class="col-center">
            <label>Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" class="input-grey" required>
        </div>

        <div class="col-12 text-end">
            <button type="submit" name="simpan" class="btn btn-primary-grey">💾 Simpan</button>
            <a href="barang.php" class="btn btn-secondary-grey">⬅️ Kembali</a>
        </div>

    </form>
</div>

</body>
</html>
